﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Learn
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void EditBatton_Click(object sender, EventArgs e)
        {
            Edit Edit = new Edit();
            Edit.Show();
            this.Hide();
        }

        private void RecordBatton_Click(object sender, EventArgs e)
        {
            Record Record = new Record();
            Record.Show();
            this.Hide();
        }

        private void ViewBatton_Click(object sender, EventArgs e)
        {
            View View = new View();
            View.Show();
            this.Hide();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "school_12ip213DataSet.Service". При необходимости она может быть перемещена или удалена.
            this.serviceTableAdapter.Fill(this.school_12ip213DataSet.Service);
            EditBatton.Enabled = false;
            RecordBatton.Enabled = false;
            ViewBatton.Enabled = false;

        }

        private void kodButton_Click(object sender, EventArgs e)
        {
            if (kodBox.Text == "0000") // если условие выполнено то кнопки станут доступны
            {
                EditBatton.Enabled = true;
                RecordBatton.Enabled = true;
                ViewBatton.Enabled = true;
            }
            else
            {
                MessageBox.Show("Incorrected passowrd!");
            }
        }
    }
}
